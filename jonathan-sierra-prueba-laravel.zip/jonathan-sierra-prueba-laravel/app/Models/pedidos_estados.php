<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pedidos_estados extends Model
{
    use HasFactory;
    protected $table = 'pedidos_estados';

    protected $fillable = [
        'estado',
        'id_pedido',
    ];

    public $timestamps = false;

}
