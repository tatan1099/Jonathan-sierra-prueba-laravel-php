<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class carritos extends Model
{
    use HasFactory;
    protected $table = 'carritos';

    protected $fillable = [
        'cantidad',
        'id_producto',
        'id_tienda',
        'id_user',
    ];

    public $timestamps = false;


}
