<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pedidos_productos extends Model
{
    use HasFactory;

    protected $table = 'pedidos_productos';

    protected $fillable = [
        'cantidad',
        'valor_unitario',
        'valor_unitario_promocion',
        'total_teorico',
        'total_final',
        'id_promocion',
        'id_producto',
        'id_pedido',
    ];

    public $timestamps = false;

}
