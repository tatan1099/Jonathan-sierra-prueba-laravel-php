<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pedidos extends Model
{
    use HasFactory;
    protected $table = 'pedidos';

    protected $fillable = [
        'instrucciones',
        'entrega_fecha',
        'valor_productos',
        'valor_envio',
        'valor_descuento',
        'valor_cupon',
        'impuestos',
        'valor_impuestos',
        'valor_final',
        'calificacion',
        'id_tienda',
        'direccion',
        'valor_comision',
        'id_user',
    ];

    public $timestamps = false;
}
